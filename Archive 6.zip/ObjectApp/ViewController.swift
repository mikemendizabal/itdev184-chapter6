//
//  ViewController.swift
//  ObjectApp
//
//  Created by user162559 on 4/16/20.
//  Copyright © 2020 Mike Mendizabal. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

